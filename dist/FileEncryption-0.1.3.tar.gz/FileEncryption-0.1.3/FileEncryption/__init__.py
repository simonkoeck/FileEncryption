__version__ = "0.1.3"
__author__ = "Simon Koeck"

from FileEncryption.main import Encryptor