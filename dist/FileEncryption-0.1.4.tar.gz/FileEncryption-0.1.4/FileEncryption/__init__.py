__version__ = "0.1.4"
__author__ = "Simon Koeck"

from FileEncryption.main import Encryptor