__version__ = "0.1.2"
__author__ = "Simon Koeck"

from FileEncryption.main import Encryptor